package com.chatrok.app.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chatrok.app.core.model.SecurityInfo
import com.chatrok.app.core.model.User
import com.chatrok.app.domain.repository.AuthRepository
import com.chatrok.app.domain.repository.SecurityRepository
import com.chatrok.app.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository,
    private val securityRepository: SecurityRepository
) : ViewModel() {

    val currentUser: StateFlow<User?> = authRepository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedUser = MutableStateFlow<User?>(null)
    val selectedUser: StateFlow<User?> = _selectedUser.asStateFlow()

    private val _securityInfo = MutableStateFlow<SecurityInfo?>(null)
    val securityInfo: StateFlow<SecurityInfo?> = _securityInfo.asStateFlow()

    private var loadUserJob: Job? = null
    private var loadSecurityJob: Job? = null

    fun loadUser(userId: String) {
        loadUserJob?.cancel()
        loadSecurityJob?.cancel()
        loadUserJob = viewModelScope.launch {
            userRepository.getUserById(userId).collect { _selectedUser.value = it }
        }
        loadSecurityJob = viewModelScope.launch {
            securityRepository.getSecurityInfo(userId).collect { _securityInfo.value = it }
        }
    }

    fun toggleVerifyIdentity(userId: String) {
        viewModelScope.launch {
            val current = _securityInfo.value ?: return@launch
            securityRepository.verifyIdentity(userId, !current.isVerified)
        }
    }

    fun toggleBlockUser(userId: String) {
        viewModelScope.launch {
            val user = _selectedUser.value ?: return@launch
            userRepository.blockUser(userId, !user.isBlocked)
        }
    }

    fun updateMyProfile(displayName: String, bio: String, onComplete: () -> Unit) {
        viewModelScope.launch {
            val current = currentUser.value ?: return@launch
            val updated = current.copy(displayName = displayName, bio = bio)
            userRepository.updateUser(updated)
            authRepository.updateProfile(displayName, bio, current.avatarUrl)
            onComplete()
        }
    }
}
