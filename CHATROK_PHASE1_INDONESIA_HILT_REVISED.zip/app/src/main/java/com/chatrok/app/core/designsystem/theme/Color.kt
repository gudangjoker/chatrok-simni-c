package com.chatrok.app.core.designsystem.theme

import androidx.compose.ui.graphics.Color

// Dark Palette (Deep Navy + Cyan/Teal + Subtle Violet)
val DarkBackground = Color(0xFF090E17)
val DarkSurface = Color(0xFF101726)
val DarkSurfaceVariant = Color(0xFF1A2338)
val DarkSurfaceContainer = Color(0xFF141D30)
val DarkSurfaceContainerHigh = Color(0xFF1E2A42)

val DarkPrimary = Color(0xFF00ADB5)
val DarkOnPrimary = Color(0xFF00292E)
val DarkPrimaryContainer = Color(0xFF004D54)
val DarkOnPrimaryContainer = Color(0xFF8CF3FF)

val DarkSecondary = Color(0xFF14B8A6)
val DarkOnSecondary = Color(0xFF003832)
val DarkSecondaryContainer = Color(0xFF0D544C)
val DarkOnSecondaryContainer = Color(0xFF5EEAD4)

val DarkTertiary = Color(0xFF818CF8) // Subtle Violet
val DarkOnTertiary = Color(0xFF1E1B4B)
val DarkTertiaryContainer = Color(0xFF312E81)
val DarkOnTertiaryContainer = Color(0xFFC7D2FE)

val DarkOutgoingBubble = Color(0xFF0C4E57)
val DarkIncomingBubble = Color(0xFF182238)
val DarkOutgoingBubbleText = Color(0xFFF0FDFA)
val DarkIncomingBubbleText = Color(0xFFF1F5F9)

// Light Palette (Clean modern slate & teal)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightSurfaceContainer = Color(0xFFF1F5F9)
val LightSurfaceContainerHigh = Color(0xFFE2E8F0)

val LightPrimary = Color(0xFF0891B2)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFCFFAFE)
val LightOnPrimaryContainer = Color(0xFF0E7490)

val LightSecondary = Color(0xFF0D9488)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFCCFBF1)
val LightOnSecondaryContainer = Color(0xFF115E59)

val LightTertiary = Color(0xFF6366F1) // Subtle Violet
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFE0E7FF)
val LightOnTertiaryContainer = Color(0xFF3730A3)

val LightOutgoingBubble = Color(0xFFCCFBF1)
val LightIncomingBubble = Color(0xFFFFFFFF)
val LightOutgoingBubbleText = Color(0xFF042F2E)
val LightIncomingBubbleText = Color(0xFF0F172A)

// Status & Receipt indicators
val StatusOnline = Color(0xFF10B981)
val StatusOffline = Color(0xFF64748B)
val ReceiptRead = Color(0xFF00ADB5)
val ReceiptDelivered = Color(0xFF94A3B8)
val ReceiptSent = Color(0xFF94A3B8)
val StatusError = Color(0xFFEF4444)
val StatusWarning = Color(0xFFF59E0B)
