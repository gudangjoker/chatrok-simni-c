package com.chatrok.app.feature.chat

import androidx.compose.ui.res.stringResource
import com.chatrok.app.R
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.chatrok.app.core.model.Attachment
import com.chatrok.app.core.model.AttachmentType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttachmentPickerSheet(
    onDismiss: () -> Unit,
    onAttachmentSelected: (Attachment, String?) -> Unit,
    onLaunchCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier.testTag("attachment_picker_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Text(
                text = stringResource(R.string.share_content),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                AttachmentOptionItem(
                    icon = Icons.Default.Image,
                    label = stringResource(R.string.photo),
                    color = Color(0xFF0284C7),
                    tag = "pick_photo_option",
                    onClick = {
                        val attachment = Attachment(
                            id = "img_" + System.currentTimeMillis(),
                            type = AttachmentType.IMAGE,
                            title = "Foto_Jadwal.jpg",
                            sizeBytes = 1420000,
                            mimeType = "image/jpeg"
                        )
                        onAttachmentSelected(attachment, "Foto papan jadwal")
                    }
                )

                AttachmentOptionItem(
                    icon = Icons.Default.Videocam,
                    label = stringResource(R.string.video),
                    color = Color(0xFF8B5CF6),
                    tag = "pick_video_option",
                    onClick = {
                        val attachment = Attachment(
                            id = "vid_" + System.currentTimeMillis(),
                            type = AttachmentType.VIDEO,
                            title = "Demo_Robotika.mp4",
                            sizeBytes = 5600000,
                            mimeType = "video/mp4"
                        )
                        onAttachmentSelected(attachment, "Video uji coba robotika")
                    }
                )

                AttachmentOptionItem(
                    icon = Icons.Default.InsertDriveFile,
                    label = stringResource(R.string.document),
                    color = Color(0xFF0D9488),
                    tag = "pick_doc_option",
                    onClick = {
                        val attachment = Attachment(
                            id = "doc_" + System.currentTimeMillis(),
                            type = AttachmentType.DOCUMENT,
                            title = "Dokumen_Internal.pdf",
                            sizeBytes = 384000,
                            mimeType = "application/pdf"
                        )
                        onAttachmentSelected(attachment, "Dokumen internal")
                    }
                )

                AttachmentOptionItem(
                    icon = Icons.Default.CameraAlt,
                    label = stringResource(R.string.camera),
                    color = Color(0xFFD97706),
                    tag = "pick_camera_option",
                    onClick = {
                        onLaunchCamera()
                    }
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun AttachmentOptionItem(
    icon: ImageVector,
    label: String,
    color: Color,
    tag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(8.dp)
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
