package com.chatrok.app.core.di

import com.chatrok.app.data.repository.FakeAuthRepository
import com.chatrok.app.data.repository.FakeCallRepository
import com.chatrok.app.data.repository.FakeConversationRepository
import com.chatrok.app.data.repository.FakeMediaRepository
import com.chatrok.app.data.repository.FakeMessageRepository
import com.chatrok.app.data.repository.FakeNotificationRepository
import com.chatrok.app.data.repository.FakePresenceRepository
import com.chatrok.app.data.repository.FakeSecurityRepository
import com.chatrok.app.data.repository.FakeUserRepository
import com.chatrok.app.domain.repository.AuthRepository
import com.chatrok.app.domain.repository.CallRepository
import com.chatrok.app.domain.repository.ConversationRepository
import com.chatrok.app.domain.repository.MediaRepository
import com.chatrok.app.domain.repository.MessageRepository
import com.chatrok.app.domain.repository.NotificationRepository
import com.chatrok.app.domain.repository.PresenceRepository
import com.chatrok.app.domain.repository.SecurityRepository
import com.chatrok.app.domain.repository.UserRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideAppScope(): CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Provides
    @Singleton
    fun provideUserRepository(): FakeUserRepository = FakeUserRepository()

    @Provides
    @Singleton
    fun provideAuthRepository(scope: CoroutineScope): FakeAuthRepository = FakeAuthRepository(scope)

    @Provides
    @Singleton
    fun providePresenceRepository(): FakePresenceRepository = FakePresenceRepository()

    @Provides
    @Singleton
    fun provideConversationRepository(
        userRepository: FakeUserRepository,
        scope: CoroutineScope
    ): FakeConversationRepository = FakeConversationRepository(userRepository, scope)

    @Provides
    @Singleton
    fun provideMessageRepository(
        conversationRepository: FakeConversationRepository,
        presenceRepository: FakePresenceRepository,
        scope: CoroutineScope
    ): FakeMessageRepository = FakeMessageRepository(conversationRepository, presenceRepository, scope)

    @Provides
    @Singleton
    fun provideMediaRepository(): FakeMediaRepository = FakeMediaRepository()

    @Provides
    @Singleton
    fun provideSecurityRepository(): FakeSecurityRepository = FakeSecurityRepository()

    @Provides
    @Singleton
    fun provideCallRepository(scope: CoroutineScope): FakeCallRepository = FakeCallRepository(scope)

    @Provides
    @Singleton
    fun provideNotificationRepository(): FakeNotificationRepository = FakeNotificationRepository()

    @Provides fun bindAuthRepository(impl: FakeAuthRepository): AuthRepository = impl
    @Provides fun bindUserRepository(impl: FakeUserRepository): UserRepository = impl
    @Provides fun bindConversationRepository(impl: FakeConversationRepository): ConversationRepository = impl
    @Provides fun bindMessageRepository(impl: FakeMessageRepository): MessageRepository = impl
    @Provides fun bindPresenceRepository(impl: FakePresenceRepository): PresenceRepository = impl
    @Provides fun bindMediaRepository(impl: FakeMediaRepository): MediaRepository = impl
    @Provides fun bindSecurityRepository(impl: FakeSecurityRepository): SecurityRepository = impl
    @Provides fun bindCallRepository(impl: FakeCallRepository): CallRepository = impl
    @Provides fun bindNotificationRepository(impl: FakeNotificationRepository): NotificationRepository = impl
}
