package com.chatrok.app.feature.inbox

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chatrok.app.core.model.CallSession
import com.chatrok.app.core.model.Conversation
import com.chatrok.app.core.model.User
import com.chatrok.app.domain.repository.CallRepository
import com.chatrok.app.domain.repository.ConversationRepository
import com.chatrok.app.domain.repository.PresenceRepository
import com.chatrok.app.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class InboxUiState(
    val conversations: List<Conversation> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val isConnected: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class InboxViewModel @Inject constructor(
    private val conversationRepository: ConversationRepository,
    private val userRepository: UserRepository,
    private val presenceRepository: PresenceRepository,
    private val callRepository: CallRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val isConnected: StateFlow<Boolean> = presenceRepository.getNetworkConnectivity()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val allUsers: StateFlow<List<User>> = userRepository.getUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callHistory: StateFlow<List<CallSession>> = callRepository.callHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uiState: StateFlow<InboxUiState> = combine(
        conversationRepository.getConversations(),
        _searchQuery,
        presenceRepository.getNetworkConnectivity()
    ) { conversations, query, connected ->
        val filtered = if (query.isBlank()) conversations else conversations.filter {
            it.otherUser.displayName.contains(query, ignoreCase = true) ||
                it.otherUser.username.contains(query, ignoreCase = true) ||
                (it.lastMessage?.text?.contains(query, ignoreCase = true) == true)
        }
        InboxUiState(filtered, query, false, connected, null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), InboxUiState(isLoading = true))

    fun onSearchQueryChange(query: String) { _searchQuery.value = query }

    fun retryConnection() {
        viewModelScope.launch { presenceRepository.simulateNetworkState(true) }
    }

    fun toggleNetworkForTesting() {
        viewModelScope.launch { presenceRepository.simulateNetworkState(!isConnected.value) }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch { conversationRepository.deleteConversation(id) }
    }

    fun createOrOpenConversation(userId: String, onResult: (String) -> Unit) {
        viewModelScope.launch { onResult(conversationRepository.getOrCreateConversationWith(userId).id) }
    }
}
