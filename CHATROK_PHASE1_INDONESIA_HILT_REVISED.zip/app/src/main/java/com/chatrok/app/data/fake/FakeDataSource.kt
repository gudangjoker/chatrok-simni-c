package com.chatrok.app.data.fake

import com.chatrok.app.core.model.Attachment
import com.chatrok.app.core.model.AttachmentType
import com.chatrok.app.core.model.CallSession
import com.chatrok.app.core.model.CallState
import com.chatrok.app.core.model.CallType
import com.chatrok.app.core.model.Conversation
import com.chatrok.app.core.model.Message
import com.chatrok.app.core.model.MessageStatus
import com.chatrok.app.core.model.MessageType
import com.chatrok.app.core.model.PresenceState
import com.chatrok.app.core.model.ReplyPreview
import com.chatrok.app.core.model.SecurityInfo
import com.chatrok.app.core.model.User

object FakeDataSource {

    val currentUser = User(
        id = "usr_me",
        username = "alex.morgan",
        displayName = "Alex Morgan",
        avatarUrl = null,
        bio = "Koordinator sistem internal & penjadwalan.",
        isOnline = true,
        lastSeen = System.currentTimeMillis(),
    )

    val users = listOf(
        User(
            id = "usr_1",
            username = "elena.rostova",
            displayName = "Elena Rostova",
            bio = "Operasional & tata kelola internal. Jalur komunikasi 1:1 rahasia.",
            isOnline = true,
            lastSeen = System.currentTimeMillis() - 2 * 60 * 1000
        ),
        User(
            id = "usr_2",
            username = "marcus.vance",
            displayName = "Marcus Vance",
            bio = "Koordinator protokol keamanan dan mitigasi risiko.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 15 * 60 * 1000
        ),
        User(
            id = "usr_3",
            username = "sarah.jenkins",
            displayName = "Sarah Jenkins",
            bio = "Analisis data dan kalkulasi metrik kinerja.",
            isOnline = true,
            lastSeen = System.currentTimeMillis()
        ),
        User(
            id = "usr_4",
            username = "david.kim",
            displayName = "David Kim",
            bio = "Spesialis perangkat keras & otomatisasi perangkat terhubung.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 45 * 60 * 1000
        ),
        User(
            id = "usr_5",
            username = "priya.patel",
            displayName = "Priya Patel",
            bio = "Dokumentasi teknis & komunikasi editorial internal.",
            isOnline = true,
            lastSeen = System.currentTimeMillis()
        ),
        User(
            id = "usr_6",
            username = "james.wilson",
            displayName = "James Wilson",
            bio = "Kepatuhan regulasi dan audit tata kelola data.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 3 * 3600 * 1000
        ),
        User(
            id = "usr_7",
            username = "maria.santos",
            displayName = "Maria Santos",
            bio = "Koordinasi relasi eksternal & aliansi strategis.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 10 * 60 * 1000
        ),
        User(
            id = "usr_8",
            username = "robert.chen",
            displayName = "Robert Chen",
            bio = "Rekayasa perangkat lunak & arsitektur kriptografi internal.",
            isOnline = true,
            lastSeen = System.currentTimeMillis()
        ),
        User(
            id = "usr_9",
            username = "fatima.mansoor",
            displayName = "Fatima Al-Mansoor",
            bio = "Manajemen aset fisik dan pengujian laboratorium.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 25 * 60 * 1000
        ),
        User(
            id = "usr_10",
            username = "thomas.miller",
            displayName = "Thomas Miller",
            bio = "Logistik fasilitas dan manajemen operasional lapangan.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 5 * 3600 * 1000
        ),
        User(
            id = "usr_11",
            username = "claire.dupont",
            displayName = "Claire Dupont",
            bio = "Dukungan sumber daya manusia dan fasilitasi internal.",
            isOnline = false,
            lastSeen = System.currentTimeMillis() - 8 * 60 * 1000
        ),
        User(
            id = "usr_12",
            username = "samuel.osei",
            displayName = "Samuel Osei",
            bio = "Operasi jaringan & pengelolaan kunci keamanan E2EE CHATROK.",
            isOnline = true,
            lastSeen = System.currentTimeMillis()
        )
    )

    private val now = System.currentTimeMillis()

    val initialMessages: MutableMap<String, MutableList<Message>> = mutableMapOf(
        "conv_1" to mutableListOf(
            Message(
                id = "m1_sec",
                conversationId = "conv_1",
                senderId = "system",
                text = "Pesan dan panggilan terenkripsi secara end-to-end. Tidak seorang pun di luar obrolan ini, bahkan CHATROK, yang dapat membaca atau mendengarkannya. Ketuk untuk memverifikasi.",
                timestamp = now - 24 * 3600 * 1000,
                type = MessageType.SYSTEM,
                isOutgoing = false
            ),
            Message(
                id = "m1_1",
                conversationId = "conv_1",
                senderId = "usr_1",
                text = "Selamat pagi Alex. Apakah jadwal evaluasi dan agenda operasional pekan depan sudah final?",
                timestamp = now - 3 * 3600 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = false
            ),
            Message(
                id = "m1_2",
                conversationId = "conv_1",
                senderId = "usr_me",
                text = "Pagi Elena. Jadwal sudah lengkap dan terverifikasi. Saya lampirkan dokumen ringkasannya di bawah ini.",
                timestamp = now - 2 * 3600 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = true
            ),
            Message(
                id = "m1_3",
                conversationId = "conv_1",
                senderId = "usr_me",
                text = "Jadwal_Operasional_Q3_2026.pdf",
                timestamp = now - 2 * 3600 * 1000 + 4000,
                status = MessageStatus.READ,
                type = MessageType.DOCUMENT,
                attachment = Attachment(
                    id = "att_1",
                    type = AttachmentType.DOCUMENT,
                    title = "Jadwal_Operasional_Q3_2026.pdf",
                    sizeBytes = 248000,
                    mimeType = "application/pdf"
                ),
                isOutgoing = true
            ),
            Message(
                id = "m1_4",
                conversationId = "conv_1",
                senderId = "usr_1",
                text = "Kerja bagus. Mari kita sinkronkan kembali pada rapat singkat sore nanti pukul 15:30 WIB.",
                timestamp = now - 45 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = false
            )
        ),
        "conv_3" to mutableListOf(
            Message(
                id = "m3_sec",
                conversationId = "conv_3",
                senderId = "system",
                text = "Pesan dan panggilan terenkripsi secara end-to-end dengan Sarah Jenkins.",
                timestamp = now - 48 * 3600 * 1000,
                type = MessageType.SYSTEM,
                isOutgoing = false
            ),
            Message(
                id = "m3_1",
                conversationId = "conv_3",
                senderId = "usr_3",
                text = "Alex, apakah verifikasi pengadaan perangkat analitik sudah disetujui?",
                timestamp = now - 18 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = false
            ),
            Message(
                id = "m3_2",
                conversationId = "conv_3",
                senderId = "usr_me",
                text = "Sudah disetujui pagi ini! Tim logistik akan langsung mengirimkan paketnya ke unit kamu.",
                timestamp = now - 12 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = true
            ),
            Message(
                id = "m3_3",
                conversationId = "conv_3",
                senderId = "usr_3",
                text = "Pesan suara (0:14)",
                timestamp = now - 6 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.VOICE_NOTE,
                attachment = Attachment(
                    id = "att_vn_1",
                    type = AttachmentType.AUDIO,
                    title = "Pesan suara",
                    sizeBytes = 86400,
                    durationSeconds = 14,
                    waveformPoints = listOf(0.2f, 0.4f, 0.7f, 0.9f, 0.6f, 0.3f, 0.8f, 1.0f, 0.6f, 0.4f, 0.5f, 0.3f, 0.2f, 0.1f)
                ),
                isOutgoing = false
            ),
            Message(
                id = "m3_4",
                conversationId = "conv_3",
                senderId = "usr_3",
                text = "Terima kasih banyak, sangat membantu sebelum uji coba sistem besok!",
                timestamp = now - 2 * 60 * 1000,
                status = MessageStatus.DELIVERED,
                type = MessageType.TEXT,
                isOutgoing = false
            )
        ),
        "conv_8" to mutableListOf(
            Message(
                id = "m8_sec",
                conversationId = "conv_8",
                senderId = "system",
                text = "Pesan terenkripsi end-to-end dengan Robert Chen.",
                timestamp = now - 36 * 3600 * 1000,
                type = MessageType.SYSTEM,
                isOutgoing = false
            ),
            Message(
                id = "m8_1",
                conversationId = "conv_8",
                senderId = "usr_8",
                text = "Kunci keamanan untuk gateway intranet telah dirotasi. Ini tangkapan konfigurasi node server.",
                timestamp = now - 50 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = false
            ),
            Message(
                id = "m8_2",
                conversationId = "conv_8",
                senderId = "usr_8",
                text = "Server Rack Node Alpha",
                timestamp = now - 48 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.IMAGE,
                attachment = Attachment(
                    id = "att_img_1",
                    type = AttachmentType.IMAGE,
                    title = "Server_Rack_Node_Alpha.jpg",
                    sizeBytes = 1048576,
                    uriOrUrl = ""
                ),
                isOutgoing = false
            ),
            Message(
                id = "m8_3",
                conversationId = "conv_8",
                senderId = "usr_me",
                text = "Semuanya rapi dan aman, Robert. Beritahu saya jika butuh penyesuaian aturan firewall.",
                timestamp = now - 15 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = true
            )
        ),
        "conv_12" to mutableListOf(
            Message(
                id = "m12_1",
                conversationId = "conv_12",
                senderId = "usr_12",
                text = "Semua sertifikat anggota tim telah tersinkronisasi dengan secure enclave CHATROK. Status verifikasi 100% aman.",
                timestamp = now - 10 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.TEXT,
                isOutgoing = false
            ),
            Message(
                id = "m12_2",
                conversationId = "conv_12",
                senderId = "usr_12",
                text = "Panggilan Suara Tak Terjawab",
                timestamp = now - 5 * 60 * 1000,
                status = MessageStatus.READ,
                type = MessageType.CALL_EVENT,
                isOutgoing = false
            )
        )
    )

    fun getInitialConversations(): List<Conversation> {
        val user1 = users.first { it.id == "usr_1" }
        val user3 = users.first { it.id == "usr_3" }
        val user8 = users.first { it.id == "usr_8" }
        val user12 = users.first { it.id == "usr_12" }
        val user4 = users.first { it.id == "usr_4" }
        val user11 = users.first { it.id == "usr_11" }

        return listOf(
            Conversation(
                id = "conv_3",
                otherUser = user3,
                lastMessage = initialMessages["conv_3"]?.lastOrNull(),
                unreadCount = 1,
                lastUpdated = now - 2 * 60 * 1000,
                isPinned = true
            ),
            Conversation(
                id = "conv_1",
                otherUser = user1,
                lastMessage = initialMessages["conv_1"]?.lastOrNull(),
                unreadCount = 0,
                lastUpdated = now - 45 * 60 * 1000,
                isPinned = true
            ),
            Conversation(
                id = "conv_12",
                otherUser = user12,
                lastMessage = initialMessages["conv_12"]?.lastOrNull(),
                unreadCount = 1,
                lastUpdated = now - 5 * 60 * 1000
            ),
            Conversation(
                id = "conv_8",
                otherUser = user8,
                lastMessage = initialMessages["conv_8"]?.lastOrNull(),
                unreadCount = 0,
                lastUpdated = now - 15 * 60 * 1000
            ),
            Conversation(
                id = "conv_4",
                otherUser = user4,
                lastMessage = Message(
                    id = "m4_init",
                    conversationId = "conv_4",
                    senderId = "usr_4",
                    text = "Pengujian modul navigasi otonom telah selesai dengan hasil optimal!",
                    timestamp = now - 4 * 3600 * 1000,
                    status = MessageStatus.READ,
                    type = MessageType.TEXT,
                    isOutgoing = false
                ),
                unreadCount = 0,
                lastUpdated = now - 4 * 3600 * 1000
            ),
            Conversation(
                id = "conv_11",
                otherUser = user11,
                lastMessage = Message(
                    id = "m11_init",
                    conversationId = "conv_11",
                    senderId = "usr_11",
                    text = "Bisa tolong periksa reservasi ruang koordinasi untuk hari Jumat nanti?",
                    timestamp = now - 26 * 3600 * 1000,
                    status = MessageStatus.READ,
                    type = MessageType.TEXT,
                    isOutgoing = false
                ),
                unreadCount = 0,
                lastUpdated = now - 26 * 3600 * 1000
            )
        )
    }

    val sampleCallHistory = listOf(
        CallSession(
            callId = "call_1",
            otherUser = users[2], // Sarah Jenkins
            type = CallType.VOICE,
            state = CallState.ENDED,
            isOutgoing = true,
            durationSeconds = 142,
            timestamp = now - 3 * 3600 * 1000
        ),
        CallSession(
            callId = "call_2",
            otherUser = users[11], // Samuel Osei
            type = CallType.VOICE,
            state = CallState.MISSED,
            isOutgoing = false,
            durationSeconds = 0,
            timestamp = now - 5 * 60 * 1000
        ),
        CallSession(
            callId = "call_3",
            otherUser = users[0], // Dr. Elena Rostova
            type = CallType.VIDEO,
            state = CallState.ENDED,
            isOutgoing = false,
            durationSeconds = 480,
            timestamp = now - 28 * 3600 * 1000
        )
    )
}
