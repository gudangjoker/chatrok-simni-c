package com.chatrok.app.feature.auth

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chatrok.app.R
import com.chatrok.app.core.model.User
import com.chatrok.app.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    @StringRes val errorResId: Int? = null,
    val isSuccess: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    val currentUser: StateFlow<User?> = authRepository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun login(email: String, pass: String) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            val result = authRepository.login(email, pass)
            result.fold(
                onSuccess = { _uiState.value = AuthUiState(isSuccess = true) },
                onFailure = { err ->
                    _uiState.value = AuthUiState(errorResId = R.string.auth_failed)
                }
            )
        }
    }

    fun register(email: String, pass: String, username: String, displayName: String) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            val result = authRepository.register(email, pass, username, displayName)
            result.fold(
                onSuccess = { _uiState.value = AuthUiState(isSuccess = true) },
                onFailure = { err ->
                    _uiState.value = AuthUiState(errorResId = R.string.registration_failed)
                }
            )
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorResId = null)
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _uiState.value = AuthUiState()
        }
    }
}
