# CHATROK Android Native — Phase 1 Frontend

CHATROK adalah prototipe messenger privat 1-ke-1 berbasis Kotlin + Jetpack Compose.

## Status Phase 1

- UI seluruhnya menggunakan Bahasa Indonesia.
- Zona waktu aplikasi: `Asia/Jakarta`.
- Locale utama: `id-ID`.
- Arsitektur: MVVM + Repository + StateFlow + Hilt.
- Repository masih menggunakan implementasi `Fake*Repository` untuk pengujian UI.
- Firebase, Cloudflare, E2EE nyata, dan LiveKit/WebRTC nyata belum dihubungkan pada Phase 1.

## Membuka proyek

1. Buka folder proyek ini dengan Android Studio.
2. Pastikan Android SDK untuk `compileSdk 36` tersedia.
3. Sinkronkan Gradle.
4. Jalankan varian `debug` pada emulator atau perangkat Android.

## Batas Phase 1

Screen keamanan hanya menampilkan placeholder integrasi E2EE. Panggilan suara/video masih berupa simulasi state lokal melalui `FakeCallRepository`.
